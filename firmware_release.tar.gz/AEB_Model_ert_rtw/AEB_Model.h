/*
 * File: AEB_Model.h
 * Auto-generated header
 */

#ifndef AEB_MODEL_H
#define AEB_MODEL_H

double AEB_BrakeLogic(double Speed, double Distance);

#endif
