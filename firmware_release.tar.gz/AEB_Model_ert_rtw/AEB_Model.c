/*
 * File: AEB_Model.c
 * Auto-generated code from MATLAB
 * Model: AEB_Model
 * Generated: 06-Dec-2025 16:16:42
 */

#include "AEB_Model.h"

double AEB_BrakeLogic(double Speed, double Distance) {
    if (Distance < 10.0 && Speed > 0.0) {
        return 1.0;  // Full brake
    } else if (Distance < 20.0) {
        return 0.5;  // Partial brake
    } else {
        return 0.0;  // No brake
    }
}
